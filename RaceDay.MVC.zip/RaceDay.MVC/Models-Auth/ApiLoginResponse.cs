﻿
namespace RaceDay.MVC.Models.Auth
{
    public class ApiLoginResponse
    {
        public string AccessToken { get; set; } = string.Empty;

        public string TokenType { get; set; } = string.Empty;

        public int ExpiresInMinutes { get; set; }

        public string Role { get; set; } = string.Empty;
    }
}
