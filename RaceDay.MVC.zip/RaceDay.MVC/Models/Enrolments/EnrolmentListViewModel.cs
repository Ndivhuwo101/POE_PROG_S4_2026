﻿
using System;
using System.Text.Json.Serialization;

namespace RaceDay.MVC.Models.Enrolments
{
    public class EnrolmentListViewModel
    {
        [JsonPropertyName("enrolment_ID")]
        public int Enrolment_ID { get; set; }

        [JsonPropertyName("category_ID")]
        public int Category_ID { get; set; }

        [JsonPropertyName("participant_ID")]
        public int Participant_ID { get; set; }

        [JsonPropertyName("enrolled_at")]
        public DateTime? Enrolled_At { get; set; }

        [JsonPropertyName("status")]
        public string? Status { get; set; }
    }
}
