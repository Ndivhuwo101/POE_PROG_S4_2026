﻿using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http;

namespace RaceDay.MVC.Models.Events
{
    public class EventViewModel
    {
        [JsonPropertyName("event_ID")]
        public int Event_ID { get; set; }

        [JsonPropertyName("organiser_ID")]
        public int Organiser_ID { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [JsonPropertyName("event_date")]
        public DateTime Event_Date { get; set; }

        [JsonPropertyName("location")]
        public string Location { get; set; } = string.Empty;

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("bannerImageUrl")]
        public string? BannerImageUrl { get; set; }

        // MVC upload property; do not send this file as JSON.
        [JsonIgnore]
        public IFormFile? BannerImage { get; set; }
    }
}