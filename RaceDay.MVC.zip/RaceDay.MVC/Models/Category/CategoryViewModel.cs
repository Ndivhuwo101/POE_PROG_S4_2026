﻿
using System.Text.Json.Serialization;

namespace RaceDay.MVC.Models.Categories
{
    public class CategoryViewModel
    {
        [JsonPropertyName("category_ID")]
        public int Category_ID { get; set; }

        [JsonPropertyName("event_ID")]
        public int Event_ID { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; } = string.Empty;

        [JsonPropertyName("distance_km")]
        public decimal Distance_Km { get; set; }

        [JsonPropertyName("max_participants")]
        public int Max_Participants { get; set; }
    }
}
