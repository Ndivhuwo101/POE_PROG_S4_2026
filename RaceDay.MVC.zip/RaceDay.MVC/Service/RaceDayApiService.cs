﻿using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;

namespace RaceDay.MVC.Services
{
    public class RaceDayApiService
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public RaceDayApiService(
            IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public HttpClient CreateClient()
        {
            return _httpClientFactory.CreateClient("RaceDayAPI");
        }

        // Upload an image to Azure through the RaceDay API
        public async Task<string?> UploadImageAsync(
            Stream imageStream,
            string fileName,
            string contentType)
        {
            using var client = CreateClient();
            using var form = new MultipartFormDataContent();
            using var imageContent = new StreamContent(imageStream);

            imageContent.Headers.ContentType =
                new MediaTypeHeaderValue(contentType);

            form.Add(imageContent, "file", fileName);

            var response = await client.PostAsync(
                "api/Images/upload", form);

            var responseBody =
                await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException(
                    $"Image upload failed: {responseBody}");
            }

            using var json = JsonDocument.Parse(responseBody);

            if (json.RootElement.TryGetProperty(
                "imageUrl", out var imageUrl))
            {
                return imageUrl.GetString();
            }

            throw new InvalidOperationException(
                "The API did not return an image URL.");
        }
    }
}