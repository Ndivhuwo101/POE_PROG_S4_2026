﻿
using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models.Enrolments;
using RaceDay.MVC.Services;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.MVC.Controllers
{
    public class EnrolmentsController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public EnrolmentsController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // GET: /Enrolments
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
            {
                return RedirectToAction("Login", "Account");
            }

            var token = HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            try
            {
                var parts = token.Split('.');

                if (parts.Length != 3)
                {
                    ViewBag.Error = "Invalid login token.";
                    return View(new List<EnrolmentViewModel>());
                }

                var payload = parts[1]
                    .Replace('-', '+')
                    .Replace('_', '/');

                payload = payload.PadRight(
                    payload.Length + (4 - payload.Length % 4) % 4, '=');

                using var document = JsonDocument.Parse(
                    Convert.FromBase64String(payload));

                var root = document.RootElement;

                string? participantClaim = null;

                if (root.TryGetProperty("nameid", out var nameId))
                {
                    participantClaim = nameId.GetString();
                }
                else if (root.TryGetProperty(
                    "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
                    out var identifier))
                {
                    participantClaim = identifier.GetString();
                }

                if (!int.TryParse(participantClaim, out int participantId))
                {
                    ViewBag.Error = "Unable to identify your participant account.";
                    return View(new List<EnrolmentViewModel>());
                }

                var client = _apiService.CreateClient();

                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                var response = await client.GetAsync("api/Enrolments");

                if (!response.IsSuccessStatusCode)
                {
                    ViewBag.Error = "Unable to retrieve your enrolments.";
                    return View(new List<EnrolmentViewModel>());
                }

                var json = await response.Content.ReadAsStringAsync();

                var enrolments =
                    JsonSerializer.Deserialize<List<EnrolmentViewModel>>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        })
                    ?? new List<EnrolmentViewModel>();

                var myEnrolments = enrolments
                    .Where(e => e.Participant_ID == participantId)
                    .OrderByDescending(e => e.Enrolled_At)
                    .ToList();

                return View(myEnrolments);
            }
            catch
            {
                ViewBag.Error =
                    "An error occurred while retrieving your enrolments.";

                return View(new List<EnrolmentViewModel>());
            }
        }

        // POST: /Enrolments/Enrol
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enrol(int categoryId, int eventId)
        {
            if (HttpContext.Session.GetString("UserRole") != "Participant")
            {
                return RedirectToAction("Login", "Account");
            }

            var token = HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            try
            {
                var parts = token.Split('.');

                if (parts.Length != 3)
                {
                    TempData["Error"] = "Invalid login token.";
                    return RedirectToAction("Details", "Events",
                        new { id = eventId });
                }

                var payload = parts[1]
                    .Replace('-', '+')
                    .Replace('_', '/');

                payload = payload.PadRight(
                    payload.Length + (4 - payload.Length % 4) % 4, '=');

                using var document = JsonDocument.Parse(
                    Convert.FromBase64String(payload));

                var root = document.RootElement;

                string? participantIdClaim = null;

                if (root.TryGetProperty("nameid", out var nameId))
                {
                    participantIdClaim = nameId.GetString();
                }
                else if (root.TryGetProperty(
                    "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
                    out var identifier))
                {
                    participantIdClaim = identifier.GetString();
                }

                if (!int.TryParse(participantIdClaim, out int participantId))
                {
                    TempData["Error"] =
                        "Unable to identify the logged-in participant.";

                    return RedirectToAction("Details", "Events",
                        new { id = eventId });
                }

                var enrolment = new EnrolmentViewModel
                {
                    Category_ID = categoryId,
                    Participant_ID = participantId,
                    Status = "Enrolled"
                };

                var client = _apiService.CreateClient();

                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                var response = await client.PostAsJsonAsync(
                    "api/Enrolments", enrolment);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] =
                        "You have successfully enrolled in this category.";
                }
                else
                {
                    var error = await response.Content.ReadAsStringAsync();

                    TempData["Error"] = "Enrolment failed: " + error;
                }

                return RedirectToAction("Details", "Events",
                    new { id = eventId });
            }
            catch
            {
                TempData["Error"] =
                    "An error occurred while processing your enrolment.";

                return RedirectToAction("Details", "Events",
                    new { id = eventId });
            }
        }
    }
}
