﻿
using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers
{
    public class ApiTestController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public ApiTestController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var client = _apiService.CreateClient();

                var response = await client.GetAsync("api/Events");

                var content = await response.Content.ReadAsStringAsync();

                ViewBag.StatusCode = (int)response.StatusCode;
                ViewBag.ApiResponse = content;

                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
        }
    }
}
