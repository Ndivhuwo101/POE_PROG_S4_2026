﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models.Events;
using RaceDay.MVC.Services;
using RaceDay.MVC.Models.Categories;
using System.Text.Json;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace RaceDay.MVC.Controllers
{
    public class EventsController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public EventsController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // GET: Events
        public async Task<IActionResult> Index()
        {
            try
            {
                var client = _apiService.CreateClient();
                var response = await client.GetAsync("api/Events");

                if (!response.IsSuccessStatusCode)
                {
                    ViewBag.Error = "Unable to retrieve events from the API.";
                    return View(new List<EventViewModel>());
                }

                var json = await response.Content.ReadAsStringAsync();

                var events = JsonSerializer.Deserialize<List<EventViewModel>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                return View(events ?? new List<EventViewModel>());
            }
            catch
            {
                ViewBag.Error = "An error occurred while connecting to the API.";
                return View(new List<EventViewModel>());
            }
        }

        // GET: Events/Details/5
        public async Task<IActionResult> Details(int id)
        {
            try
            {
                var client = _apiService.CreateClient();

                var eventResponse = await client.GetAsync($"api/Events/{id}");

                if (!eventResponse.IsSuccessStatusCode)
                    return NotFound("Event not found.");

                var eventJson = await eventResponse.Content.ReadAsStringAsync();

                var raceEvent = JsonSerializer.Deserialize<EventViewModel>(
                    eventJson,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                if (raceEvent == null)
                    return NotFound("Event not found.");

                var categoryResponse =
                    await client.GetAsync($"api/events/{id}/categories");

                if (categoryResponse.IsSuccessStatusCode)
                {
                    var categoryJson =
                        await categoryResponse.Content.ReadAsStringAsync();

                    ViewBag.Categories =
                        JsonSerializer.Deserialize<List<CategoryViewModel>>(
                            categoryJson,
                            new JsonSerializerOptions
                            {
                                PropertyNameCaseInsensitive = true
                            }) ?? new List<CategoryViewModel>();
                }
                else
                {
                    ViewBag.Categories = new List<CategoryViewModel>();
                    ViewBag.CategoryError =
                        "Unable to retrieve categories for this event.";
                }

                return View(raceEvent);
            }
            catch
            {
                return StatusCode(500,
                    "An error occurred while retrieving event details.");
            }
        }

        // GET: Events/Create
        [HttpGet]
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            return View(new EventViewModel());
        }

        // POST: Events/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EventViewModel model)
        {
            if (HttpContext.Session.GetString("UserRole") != "Organiser")
                return RedirectToAction("Login", "Account");

            var token = HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrWhiteSpace(token))
                return RedirectToAction("Login", "Account");

            try
            {
                // Upload selected banner to Azure through the API
                if (model.BannerImage != null &&
                    model.BannerImage.Length > 0)
                {
                    using var stream = model.BannerImage.OpenReadStream();

                    model.BannerImageUrl =
                        await _apiService.UploadImageAsync(
                            stream,
                            model.BannerImage.FileName,
                            model.BannerImage.ContentType);
                }

                using var client = _apiService.CreateClient();

                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);

                var eventData = new
                {
                    name = model.Name,
                    event_date = model.Event_Date,
                    location = model.Location,
                    description = model.Description,
                    banner_image_url = model.BannerImageUrl
                };

                var response = await client.PostAsJsonAsync(
                    "api/Events", eventData);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Success"] = "Event created successfully.";
                    return RedirectToAction(nameof(Index));
                }

                var error = await response.Content.ReadAsStringAsync();

                ModelState.AddModelError(
                    string.Empty,
                    $"Unable to create event. {error}");

                return View(model);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(
                    string.Empty,
                    $"An error occurred: {ex.Message}");

                return View(model);
            }
        }
    }
}