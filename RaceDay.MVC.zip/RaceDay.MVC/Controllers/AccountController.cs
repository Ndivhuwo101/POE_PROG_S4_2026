﻿
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using RaceDay.MVC.Models.Auth;
using RaceDay.MVC.Services;

namespace RaceDay.MVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly RaceDayApiService _apiService;

        public AccountController(RaceDayApiService apiService)
        {
            _apiService = apiService;
        }

        // LOGIN PAGE
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // PROCESS LOGIN
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var client = _apiService.CreateClient();

                var response = await client.PostAsJsonAsync(
                    "api/Auth/login", model);

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Invalid email or password.");

                    return View(model);
                }

                var result = await response.Content
                    .ReadFromJsonAsync<ApiLoginResponse>();

                if (result == null ||
                    string.IsNullOrWhiteSpace(result.AccessToken))
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "The API returned an invalid login response.");

                    return View(model);
                }

                // Store authentication information in session
                HttpContext.Session.SetString(
                    "JWToken", result.AccessToken);

                HttpContext.Session.SetString(
                    "UserRole", result.Role);

                HttpContext.Session.SetString(
                    "UserEmail", model.Email);

                if (result.Role == "Organiser")
                    return RedirectToAction("Dashboard", "Organiser");

                return RedirectToAction("Index", "Home");
            }
            catch
            {
                ModelState.AddModelError(
                    string.Empty,
                    "Unable to connect to the RaceDay API.");

                return View(model);
            }
        }

        // PARTICIPANT REGISTRATION PAGE
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // PROCESS PARTICIPANT REGISTRATION
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(
            RegisterParticipantViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                var client = _apiService.CreateClient();

                var response = await client.PostAsJsonAsync(
                    "api/Auth/register-participant", model);

                if (!response.IsSuccessStatusCode)
                {
                    ModelState.AddModelError(
                        string.Empty,
                        "Registration failed. Please check your details.");

                    return View(model);
                }

                TempData["Success"] =
                    "Registration successful! Please log in.";

                return RedirectToAction("Login");
            }
            catch
            {
                ModelState.AddModelError(
                    string.Empty,
                    "Unable to connect to the RaceDay API.");

                return View(model);
            }
        }

        // LOGOUT
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();

            return RedirectToAction("Login");
        }
    }
}
