﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using raceDay.Models;
using RaceDay.API.Models;

namespace RaceDay.API.Data
{
    public class RaceDayContext : DbContext
    {
        public RaceDayContext(
            DbContextOptions<RaceDayContext> options)
            : base(options)
        {
        }

        // Existing database tables
        public DbSet<Organiser> Organisers { get; set; }
        public DbSet<Events> Events { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Enrolment> Enrolments { get; set; }
            = null!;
        public DbSet<Participant> Participants { get; set; }
        public DbSet<Result> Results { get; set; } = null!;


        protected override void OnModelCreating(
            ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // =========================================
            // ORGANISER TABLE
            // Namespace: raceDay.Models
            // =========================================
            modelBuilder.Entity<Organiser>(entity =>
            {
                entity.ToTable("Organiser");

                entity.HasKey(e => e.Organiser_ID);

                entity.HasIndex(e => e.Email)
                      .IsUnique();

                entity.Property(e => e.FirstName)
                      .HasColumnName("first_name")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.LastName)
                      .HasColumnName("last_name")
                      .HasMaxLength(50)
                      .IsRequired();

                entity.Property(e => e.Email)
                      .HasColumnName("email")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.PasswordHash)
                      .HasColumnName("password_hash")
                      .HasMaxLength(255)
                      .IsRequired();

                entity.Property(e => e.CreatedAt)
                      .HasColumnName("created_at")
                      .HasDefaultValueSql("GETDATE()");
            });

            // =========================================
            // EVENTS TABLE
            // Namespace: RaceDay.API.Models
            // =========================================

            modelBuilder.Entity<Events>(entity =>
            {
                entity.ToTable("Events");

                entity.HasKey(e => e.Event_ID);

                entity.Property(e => e.Event_ID)
                      .HasColumnName("Event_ID")
                      .ValueGeneratedOnAdd();

                entity.Property(e => e.Organiser_ID)
                      .HasColumnName("Organiser_ID")
                      .IsRequired();

                entity.Property(e => e.name)
                      .HasColumnName("name")
                      .HasMaxLength(100)
                      .IsRequired();

                entity.Property(e => e.event_date)
                      .HasColumnName("event_date")
                      .HasColumnType("date")
                      .IsRequired();

                entity.Property(e => e.location)
                      .HasColumnName("location")
                      .HasMaxLength(150)
                      .IsRequired();

                entity.Property(e => e.description)
                      .HasColumnName("description")
                      .HasColumnType("varchar(max)");

                entity.Property(e => e.created_at)
                      .HasColumnName("created_at")
                      .HasDefaultValueSql("GETDATE()");

                entity.HasOne(e => e.Organiser)
                      .WithMany()
                      .HasForeignKey(e => e.Organiser_ID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            // =========================================
            // CATEGORY TABLE
            // Namespace: RaceDay.API.Models
            // =========================================
            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("Category", "dbo");

                entity.HasKey(e => e.Category_ID);

                entity.Property(e => e.Event_ID)
                    .HasColumnName("Event_ID")
                    .IsRequired();

                entity.Property(e => e.name)
                    .HasColumnName("name")
                    .HasMaxLength(100)
                    .IsRequired();

                entity.Property(e => e.distance_km)
                    .HasColumnName("distance_km")
                    .HasColumnType("decimal(6,2)")
                    .IsRequired();

                entity.Property(e => e.max_participants)
                    .HasColumnName("max_participants")
                    .IsRequired();

                entity.HasOne(e => e.Event)
                    .WithMany()
                    .HasForeignKey(e => e.Event_ID)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // =========================================
            // PARTICIPANT TABLE
            // Namespace: RaceDay.API.Models
            // =========================================
            modelBuilder.Entity<Participant>(entity =>
            {
                entity.ToTable("Participant");

                entity.HasKey(e => e.Participant_ID);

                entity.Property(e => e.first_name)
                      .HasColumnName("first_name")
                      .IsRequired();

                entity.Property(e => e.last_name)
                      .HasColumnName("last_name")
                      .IsRequired();

                entity.Property(e => e.email)
                      .HasColumnName("email")
                      .IsRequired();

                entity.Property(e => e.password_hash)
                      .HasColumnName("password_hash")
                      .IsRequired();

                entity.Property(e => e.date_of_birth)
                      .HasColumnName("date_of_birth")
                      .HasColumnType("date");

                entity.Property(e => e.gender)
                      .HasColumnName("gender");

                entity.Property(e => e.created_at)
                      .HasColumnName("created_at");
            });

            // =========================================
            // ENROLLMENT TABLE
            // Namespace: RaceDay.API.Models
            // =========================================
            modelBuilder.Entity<Enrolment>(entity =>
            {
                entity.ToTable("Enrolment");
                entity.HasKey(e => e.Enrolment_ID);

                entity.Property(e => e.enrolled_at)
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.status)
                    .HasMaxLength(30)
                    .HasDefaultValue("Enrolled");

                entity.HasOne(e => e.Category)
                    .WithMany()
                    .HasForeignKey(e => e.Category_ID);

                entity.HasOne(e => e.Participant)
                    .WithMany()
                    .HasForeignKey(e => e.Participant_ID);
            });

            modelBuilder.Entity<Result>(entity =>
            {
                entity.ToTable("Result");
                entity.HasKey(e => e.Result_ID);

                entity.HasOne(e => e.Enrolment)
                    .WithMany(e => e.Results)
                    .HasForeignKey(e => e.Enrolment_ID);

                entity.HasOne(e => e.Organiser)
                    .WithMany()
                    .HasForeignKey(e => e.Organiser_ID);
            });
        }
    }
}
