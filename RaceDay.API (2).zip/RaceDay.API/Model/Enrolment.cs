﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDay.API.Models
{
    [Table("Enrolment")]
    public class Enrolment
    {
        [Key]
        public int Enrolment_ID { get; set; }

        public int Category_ID { get; set; }

        public int Participant_ID { get; set; }

        public DateTime? enrolled_at { get; set; }

        [StringLength(30)]
        public string? status { get; set; }

        // Relationships
        [ForeignKey(nameof(Category_ID))]
        public Category? Category { get; set; }

        [ForeignKey(nameof(Participant_ID))]
        public Participant? Participant { get; set; }

        public ICollection<Result> Results { get; set; }
            = new List<Result>();
    }
}
