﻿using System;

namespace RaceDay.API.Models
{
    public class Participant
    {
        public int Participant_ID { get; set; }

        public string first_name { get; set; } = string.Empty;

        public string last_name { get; set; } = string.Empty;

        public string email { get; set; } = string.Empty;

        public string password_hash { get; set; } = string.Empty;

        public DateTime date_of_birth { get; set; }

        public string? gender { get; set; }

        public DateTime? created_at { get; set; }
    }
}