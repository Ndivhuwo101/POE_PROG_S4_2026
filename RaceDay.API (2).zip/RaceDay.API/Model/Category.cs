﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDay.API.Models
{
    [Table("Category")]
    public class Category
    {
        [Key]
        public int Category_ID { get; set; }

        public int Event_ID { get; set; }

        [Required]
        [StringLength(100)]
        public string name { get; set; } = string.Empty;

        [Column(TypeName = "decimal(10,2)")]
        public decimal distance_km { get; set; }

        public int max_participants { get; set; }

        // Navigation property
        [ForeignKey(nameof(Event_ID))]
        public Events? Event { get; set; }
    }
}
