﻿using raceDay.Models;
using System;
using System.Collections.Generic;

namespace RaceDay.API.Models
{
    public class Events
    {
        public int Event_ID { get; set; }

        public int Organiser_ID { get; set; }

        public string name { get; set; } = string.Empty;

        public DateTime event_date { get; set; }

        public string location { get; set; } = string.Empty;

        public string? description { get; set; }

        public DateTime created_at { get; set; }

        // Azure Blob Storage image URL
        public string? banner_image_url { get; set; }

        // Relationship to Organiser
        public Organiser? Organiser { get; set; }
    }
}