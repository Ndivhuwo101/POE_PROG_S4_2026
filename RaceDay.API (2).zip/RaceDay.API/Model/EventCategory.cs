﻿
namespace RaceDay.API.Models
{
    public class EventCategory
    {
        public int Event_ID { get; set; }

        public int Category_ID { get; set; }

        // Navigation property to the Events entity
        public Events? Event { get; set; }

        // Navigation property to the Category entity
        public Category? Category { get; set; }
    }
}
