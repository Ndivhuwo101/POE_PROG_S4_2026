﻿
using raceDay.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RaceDay.API.Models
{
    [Table("Result")]
    public class Result
    {
        [Key]
        public int Result_ID { get; set; }

        public int Enrolment_ID { get; set; }

        public int Organiser_ID { get; set; }

        public TimeSpan finish_time { get; set; }

        public int position { get; set; }

        public DateTime captured_at { get; set; }

        // Relationships
        [ForeignKey(nameof(Enrolment_ID))]
        public Enrolment? Enrolment { get; set; }

        [ForeignKey(nameof(Organiser_ID))]
        public Organiser? Organiser { get; set; }
    }
}
