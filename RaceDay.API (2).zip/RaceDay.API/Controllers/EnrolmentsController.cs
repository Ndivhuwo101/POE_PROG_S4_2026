﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public EnrolmentsController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Enrolments
        [HttpGet]
        public async Task<IActionResult> GetEnrolments()
        {
            var enrolments = await _context.Enrolments
                .AsNoTracking()
                .ToListAsync();

            return Ok(enrolments);
        }

        // GET: api/Enrolments/1
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetEnrolment(int id)
        {
            var enrolment = await _context.Enrolments
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Enrolment_ID == id);

            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found." });

            return Ok(enrolment);
        }

        // POST: api/Enrolments
        [HttpPost]
        public async Task<IActionResult> CreateEnrolment(
            [FromBody] Enrolment enrolment)
        {
            var categoryExists = await _context.Categories
                .AnyAsync(c => c.Category_ID == enrolment.Category_ID);

            if (!categoryExists)
                return BadRequest(new
                {
                    message = "Category not found."
                });

            var participantExists = await _context.Participants
                .AnyAsync(p => p.Participant_ID == enrolment.Participant_ID);

            if (!participantExists)
                return BadRequest(new
                {
                    message = "Participant not found."
                });

            enrolment.Enrolment_ID = 0;
            enrolment.enrolled_at = null;

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetEnrolment),
                new { id = enrolment.Enrolment_ID },
                enrolment);
        }

        // PUT: api/Enrolments/1
        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateEnrolment(
            int id,
            [FromBody] Enrolment enrolment)
        {
            if (id != enrolment.Enrolment_ID)
                return BadRequest(new
                {
                    message = "The URL ID and body ID must match."
                });

            var existing = await _context.Enrolments.FindAsync(id);

            if (existing == null)
                return NotFound(new
                {
                    message = "Enrolment not found."
                });

            var categoryExists = await _context.Categories
                .AnyAsync(c => c.Category_ID == enrolment.Category_ID);

            if (!categoryExists)
                return BadRequest(new
                {
                    message = "Category not found."
                });

            var participantExists = await _context.Participants
                .AnyAsync(p => p.Participant_ID == enrolment.Participant_ID);

            if (!participantExists)
                return BadRequest(new
                {
                    message = "Participant not found."
                });

            existing.Category_ID = enrolment.Category_ID;
            existing.Participant_ID = enrolment.Participant_ID;
            existing.status = enrolment.status;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Enrolments/1
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteEnrolment(int id)
        {
            var enrolment = await _context.Enrolments.FindAsync(id);

            if (enrolment == null)
                return NotFound(new
                {
                    message = "Enrolment not found."
                });

            var hasResults = await _context.Results
                .AnyAsync(r => r.Enrolment_ID == id);

            if (hasResults)
                return Conflict(new
                {
                    message = "Cannot delete this enrolment because results are linked to it."
                });

            _context.Enrolments.Remove(enrolment);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

