﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;
using System.Security.Claims;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public EventsController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Events
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetEvents()
        {
            var events = await _context.Events
                .AsNoTracking()
                .OrderBy(e => e.event_date)
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/Events/5
        [HttpGet("{id:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetEvent(int id)
        {
            var raceEvent = await _context.Events
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Event_ID == id);

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            return Ok(raceEvent);
        }

        // POST: api/Events
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateEvent([FromBody] Events request)
        {
            int? organiserId = GetOrganiserId();

            if (organiserId == null)
                return Unauthorized(new { message = "Organiser ID not found in token." });

            if (string.IsNullOrWhiteSpace(request.name) ||
                string.IsNullOrWhiteSpace(request.location))
            {
                return BadRequest(new
                {
                    message = "Event name and location are required."
                });
            }

            var newEvent = new Events
            {
                Organiser_ID = organiserId.Value,
                name = request.name,
                event_date = request.event_date,
                location = request.location,
                description = request.description,
                banner_image_url = request.banner_image_url,
                created_at = DateTime.Now
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetEvent),
                new { id = newEvent.Event_ID },
                newEvent);
        }

        // PUT: api/Events/5
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateEvent(
            int id,
            [FromBody] Events request)
        {
            int? organiserId = GetOrganiserId();

            if (organiserId == null)
                return Unauthorized();

            var existingEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.Event_ID == id);

            if (existingEvent == null)
                return NotFound(new { message = "Event not found." });

            if (existingEvent.Organiser_ID != organiserId.Value)
                return Forbid();

            existingEvent.name = request.name;
            existingEvent.event_date = request.event_date;
            existingEvent.location = request.location;
            existingEvent.description = request.description;
            existingEvent.banner_image_url = request.banner_image_url;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Event updated successfully.",
                eventDetails = existingEvent
            });
        }

        // DELETE: api/Events/5
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            int? organiserId = GetOrganiserId();

            if (organiserId == null)
                return Unauthorized();

            var existingEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.Event_ID == id);

            if (existingEvent == null)
                return NotFound(new { message = "Event not found." });

            if (existingEvent.Organiser_ID != organiserId.Value)
                return Forbid();

            _context.Events.Remove(existingEvent);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event deleted successfully." });
        }

        // Retrieve organiser ID from JWT claims
        private int? GetOrganiserId()
        {
            var idClaim =
                User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                ?? User.FindFirst("nameid")?.Value
                ?? User.FindFirst("sub")?.Value;

            if (int.TryParse(idClaim, out int organiserId))
                return organiserId;

            return null;
        }
    }
}