﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using raceDay.Models;
using Microsoft.AspNetCore.Authorization;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Organiser")]
   
    public class OrganisersController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public OrganisersController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Organisers
        [HttpGet]
        public async Task<IActionResult> GetOrganisers()
        {
            var organisers = await _context.Organisers
                .AsNoTracking()
                .Select(o => new
                {
                    o.Organiser_ID,
                    o.FirstName,
                    o.LastName,
                    o.Email,
                    o.CreatedAt
                })
                .ToListAsync();

            return Ok(organisers);
        }

        // GET: api/Organisers/1
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetOrganiser(int id)
        {
            var organiser = await _context.Organisers
                .AsNoTracking()
                .Where(o => o.Organiser_ID == id)
                .Select(o => new
                {
                    o.Organiser_ID,
                    o.FirstName,
                    o.LastName,
                    o.Email,
                    o.CreatedAt
                })
                .FirstOrDefaultAsync();

            if (organiser == null)
                return NotFound(new
                {
                    message = "Organiser not found."
                });

            return Ok(organiser);
        }

        // POST: api/Organisers
        [HttpPost]
        public async Task<IActionResult> CreateOrganiser(
            [FromBody] Organiser organiser)
        {
            var emailExists = await _context.Organisers
                .AnyAsync(o => o.Email == organiser.Email);

            if (emailExists)
                return Conflict(new
                {
                    message = "An organiser with this email already exists."
                });

            organiser.Organiser_ID = 0;
            organiser.CreatedAt = DateTime.Now;

            _context.Organisers.Add(organiser);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetOrganiser),
                new { id = organiser.Organiser_ID },
                new
                {
                    organiser.Organiser_ID,
                    organiser.FirstName,
                    organiser.LastName,
                    organiser.Email,
                    organiser.CreatedAt
                });
        }

        // PUT: api/Organisers/1
        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateOrganiser(
            int id,
            [FromBody] Organiser organiser)
        {
            if (id != organiser.Organiser_ID)
                return BadRequest(new
                {
                    message = "The URL ID and body ID must match."
                });

            var existing = await _context.Organisers.FindAsync(id);

            if (existing == null)
                return NotFound(new
                {
                    message = "Organiser not found."
                });

            var duplicateEmail = await _context.Organisers
                .AnyAsync(o =>
                    o.Email == organiser.Email &&
                    o.Organiser_ID != id);

            if (duplicateEmail)
                return Conflict(new
                {
                    message = "Another organiser already uses this email."
                });

            existing.FirstName = organiser.FirstName;
            existing.LastName = organiser.LastName;
            existing.Email = organiser.Email;

            // Keep the existing password hash and creation date.

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Organisers/1
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteOrganiser(int id)
        {
            var organiser = await _context.Organisers.FindAsync(id);

            if (organiser == null)
                return NotFound(new
                {
                    message = "Organiser not found."
                });

            var hasEvents = await _context.Events
                .AnyAsync(e => e.Organiser_ID == id);

            var hasResults = await _context.Results
                .AnyAsync(r => r.Organiser_ID == id);

            if (hasEvents || hasResults)
                return Conflict(new
                {
                    message = "Cannot delete an organiser linked to events or results."
                });

            _context.Organisers.Remove(organiser);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
