﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/events/{id:int}/categories")]
    public class EventCategoriesController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public EventCategoriesController(RaceDayContext context)
        {
            _context = context;
        }

        // GET /api/events/{id}/categories
        [HttpGet]
        public async Task<IActionResult> GetCategories(int id)
        {
            bool eventExists = await _context.Events
                .AnyAsync(e => e.Event_ID == id);

            if (!eventExists)
                return NotFound(new { message = "Event not found." });

            var categories = await _context.Categories
                .AsNoTracking()
                .Where(c => c.Event_ID == id)
                .ToListAsync();

            return Ok(categories);
        }

        // POST /api/events/{id}/categories
        [HttpPost]
        public async Task<IActionResult> CreateCategory(
            int id,
            [FromBody] CreateCategoryDto dto)
        {
            bool eventExists = await _context.Events
                .AnyAsync(e => e.Event_ID == id);

            if (!eventExists)
                return NotFound(new { message = "Event not found." });

            if (string.IsNullOrWhiteSpace(dto.name))
                return BadRequest(new { message = "Category name is required." });

            var category = new Category
            {
                Event_ID = id,
                name = dto.name.Trim(),
                distance_km = dto.distance_km,
                max_participants = dto.max_participants
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetCategories),
                new { id = id },
                category);
        }
    }
}
