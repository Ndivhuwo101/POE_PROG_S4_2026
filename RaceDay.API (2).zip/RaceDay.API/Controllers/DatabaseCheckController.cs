﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using System.Collections.Generic;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DatabaseCheckController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public DatabaseCheckController(RaceDayContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                bool connected =
                    await _context.Database.CanConnectAsync();

                if (!connected)
                {
                    return StatusCode(503, new
                    {
                        message = "Cannot connect to RaceDayDB."
                    });
                }

                return Ok(new
                {
                    message = "Connected to RaceDayDB successfully."
                });
            }
            catch (Exception)
            {
                return StatusCode(503, new
                {
                    message = "Database connection failed. Check the connection string and SQL Server."
                });
            }
        }

       [HttpGet("tables")]
        public async Task<IActionResult> CheckTables()
        {
            try
            {
                var tableCounts = new
                {
                    Category = await _context.Categories.CountAsync(),
                    Enrolment = await _context.Enrolments.CountAsync(),
                    Events = await _context.Events.CountAsync(),
                    Organiser = await _context.Organisers.CountAsync(),
                    Participant = await _context.Participants.CountAsync(),
                    Result = await _context.Results.CountAsync()
                };

                return Ok(new
                {
                    message = "All six table mappings were queried successfully.",
                    tableCounts
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "A table mapping could not be verified.",
                    error = ex.GetBaseException().Message
                });
            }
        }
    }
    }

