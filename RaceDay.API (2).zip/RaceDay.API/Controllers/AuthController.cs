﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
using raceDay.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly RaceDayContext _context;
        private readonly IConfiguration _configuration;

        private readonly PasswordHasher<Participant> _participantHasher = new();
        private readonly PasswordHasher<Organiser> _organiserHasher = new();

        public AuthController(
            RaceDayContext context,
            IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // PARTICIPANT REGISTRATION
        [HttpPost("register-participant")]
        public async Task<IActionResult> RegisterParticipant(
            RegisterParticipantDto request)
        {
            string email = request.Email.Trim();

            if (request.DateOfBirth.Date >= DateTime.UtcNow.Date)
                return BadRequest("Date of birth must be in the past.");

            if (await _context.Participants.AnyAsync(
                    p => p.email == email) ||
                await _context.Organisers.AnyAsync(
                    o => o.Email == email))
            {
                return Conflict("An account with this email already exists.");
            }

            var participant = new Participant
            {
                first_name = request.FirstName.Trim(),
                last_name = request.LastName.Trim(),
                email = email,
                date_of_birth = request.DateOfBirth.Date,
                gender = request.Gender,
                created_at = DateTime.UtcNow
            };

            participant.password_hash =
                _participantHasher.HashPassword(
                    participant, request.Password);

            _context.Participants.Add(participant);
            await _context.SaveChangesAsync();

            return StatusCode(201, new
            {
                message = "Participant registered successfully.",
                participant.Participant_ID,
                participant.first_name,
                participant.last_name,
                participant.email
            });
        }

        // ORGANISER REGISTRATION
        // Only an authenticated Organiser can create another Organiser.
        [Authorize(Roles = "Organiser")]
        [HttpPost("register-organiser")]
        public async Task<IActionResult> RegisterOrganiser(
            RegisterOrganiserDto request)
        {
            string email = request.Email.Trim();

            if (await _context.Participants.AnyAsync(
                    p => p.email == email) ||
                await _context.Organisers.AnyAsync(
                    o => o.Email == email))
            {
                return Conflict("An account with this email already exists.");
            }

            var organiser = new Organiser
            {
                FirstName = request.FirstName.Trim(),
                LastName = request.LastName.Trim(),
                Email = email,
                CreatedAt = DateTime.UtcNow
            };

            organiser.PasswordHash =
                _organiserHasher.HashPassword(
                    organiser, request.Password);

            _context.Organisers.Add(organiser);
            await _context.SaveChangesAsync();

            return StatusCode(201, new
            {
                message = "Organiser registered successfully.",
                organiser.Organiser_ID,
                organiser.FirstName,
                organiser.LastName,
                organiser.Email
            });
        }

        // LOGIN FOR PARTICIPANTS AND ORGANISERS
        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto request)
        {
            string email = request.Email.Trim();

            var participant = await _context.Participants
                .FirstOrDefaultAsync(p => p.email == email);

            if (participant != null)
            {
                var result = _participantHasher.VerifyHashedPassword(
                    participant,
                    participant.password_hash,
                    request.Password);

                if (result != PasswordVerificationResult.Failed)
                {
                    return Ok(CreateToken(
                        participant.Participant_ID,
                        participant.email,
                        participant.first_name,
                        "Participant"));
                }

                return Unauthorized("Invalid email or password.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.Email == email);

            if (organiser != null)
            {
                var result = _organiserHasher.VerifyHashedPassword(
                    organiser,
                    organiser.PasswordHash,
                    request.Password);

                if (result != PasswordVerificationResult.Failed)
                {
                    return Ok(CreateToken(
                        organiser.Organiser_ID,
                        organiser.Email,
                        organiser.FirstName,
                        "Organiser"));
                }
            }

            return Unauthorized("Invalid email or password.");
        }

        private object CreateToken(
            int id,
            string email,
            string name,
            string role)
        {
            string key = _configuration["Jwt:Key"]
                ?? throw new InvalidOperationException(
                    "JWT signing key is not configured.");

            var signingKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(key));

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, id.ToString()),
                new Claim(ClaimTypes.Email, email),
                new Claim(ClaimTypes.Name, name),
                new Claim(ClaimTypes.Role, role)
            };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(60),
                signingCredentials: new SigningCredentials(
                    signingKey, SecurityAlgorithms.HmacSha256));

            return new
            {
                accessToken = new JwtSecurityTokenHandler()
                    .WriteToken(token),
                tokenType = "Bearer",
                expiresInMinutes = 60,
                role
            };
        }
    }
}
