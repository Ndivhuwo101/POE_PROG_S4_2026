﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;
using Microsoft.AspNetCore.Authorization;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Participant")]
    public class ParticipantsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public ParticipantsController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Participants
        [HttpGet]
        public async Task<IActionResult> GetParticipants()
        {
            var participants = await _context.Participants
                .AsNoTracking()
                .Select(p => new
                {
                    p.Participant_ID,
                    p.first_name,
                    p.last_name,
                    p.email,
                    p.date_of_birth,
                    p.gender,
                    p.created_at
                })
                .ToListAsync();

            return Ok(participants);
        }

        // GET: api/Participants/1
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetParticipant(int id)
        {
            var participant = await _context.Participants
                .AsNoTracking()
                .Where(p => p.Participant_ID == id)
                .Select(p => new
                {
                    p.Participant_ID,
                    p.first_name,
                    p.last_name,
                    p.email,
                    p.date_of_birth,
                    p.gender,
                    p.created_at
                })
                .FirstOrDefaultAsync();

            if (participant == null)
                return NotFound(new
                {
                    message = "Participant not found."
                });

            return Ok(participant);
        }

        // POST: api/Participants
        [HttpPost]
        public async Task<IActionResult> CreateParticipant(
            [FromBody] Participant participant)
        {
            var emailExists = await _context.Participants
                .AnyAsync(p => p.email == participant.email);

            if (emailExists)
                return Conflict(new
                {
                    message = "A participant with this email already exists."
                });

            participant.Participant_ID = 0;
            participant.created_at = DateTime.Now;

            _context.Participants.Add(participant);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetParticipant),
                new { id = participant.Participant_ID },
                new
                {
                    participant.Participant_ID,
                    participant.first_name,
                    participant.last_name,
                    participant.email,
                    participant.date_of_birth,
                    participant.gender,
                    participant.created_at
                });
        }

        // PUT: api/Participants/1
        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateParticipant(
            int id,
            [FromBody] Participant participant)
        {
            if (id != participant.Participant_ID)
                return BadRequest(new
                {
                    message = "The URL ID and body ID must match."
                });

            var existing = await _context.Participants.FindAsync(id);

            if (existing == null)
                return NotFound(new
                {
                    message = "Participant not found."
                });

            var duplicateEmail = await _context.Participants
                .AnyAsync(p =>
                    p.email == participant.email &&
                    p.Participant_ID != id);

            if (duplicateEmail)
                return Conflict(new
                {
                    message = "Another participant already uses this email."
                });

            existing.first_name = participant.first_name;
            existing.last_name = participant.last_name;
            existing.email = participant.email;
            existing.date_of_birth = participant.date_of_birth;
            existing.gender = participant.gender;

            // Do not update password_hash or created_at here.

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Participants/1
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteParticipant(int id)
        {
            var participant = await _context.Participants.FindAsync(id);

            if (participant == null)
                return NotFound(new
                {
                    message = "Participant not found."
                });

            var hasEnrolments = await _context.Enrolments
                .AnyAsync(e => e.Participant_ID == id);

            if (hasEnrolments)
                return Conflict(new
                {
                    message = "Cannot delete a participant with existing enrolments."
                });

            _context.Participants.Remove(participant);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
