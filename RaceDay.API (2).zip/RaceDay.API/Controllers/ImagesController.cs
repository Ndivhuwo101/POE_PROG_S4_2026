﻿
using Azure;
using Microsoft.AspNetCore.Mvc;
using RaceDay.API.Services;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ImagesController : ControllerBase
    {
        private readonly BlobStorageService _blobStorage;

        public ImagesController(BlobStorageService blobStorage)
        {
            _blobStorage = blobStorage;
        }

        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadImage(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new
                {
                    message = "Please select an image."
                });
            }

            const long maxFileSize = 5 * 1024 * 1024;

            if (file.Length > maxFileSize)
            {
                return BadRequest(new
                {
                    message = "Image size cannot exceed 5 MB."
                });
            }

            var allowedTypes = new[]
            {
                "image/jpeg",
                "image/png",
                "image/webp"
            };

            if (!allowedTypes.Contains(file.ContentType.ToLowerInvariant()))
            {
                return BadRequest(new
                {
                    message = "Only JPG, PNG and WEBP images are allowed."
                });
            }

            var extension = Path.GetExtension(file.FileName)
                .ToLowerInvariant();

            var allowedExtensions = new[]
            {
                ".jpg", ".jpeg", ".png", ".webp"
            };

            if (!allowedExtensions.Contains(extension))
            {
                return BadRequest(new
                {
                    message = "Invalid image file extension."
                });
            }

            try
            {
                using var stream = file.OpenReadStream();

                var blobName = await _blobStorage.UploadAsync(
                    stream,
                    file.FileName,
                    file.ContentType);

                var imageUrl = Url.Action(
                    nameof(GetImage),
                    "Images",
                    new { blobName },
                    Request.Scheme);

                return Created(imageUrl, new
                {
                    message = "Image uploaded successfully.",
                    blobName,
                    imageUrl
                });
            }
            catch (RequestFailedException)
            {
                return StatusCode(502, new
                {
                    message = "Azure Blob Storage could not complete the upload."
                });
            }
        }

        [HttpGet("{blobName}")]
        public async Task<IActionResult> GetImage(string blobName)
        {
            if (string.IsNullOrWhiteSpace(blobName) ||
                Path.GetFileName(blobName) != blobName)
            {
                return BadRequest(new
                {
                    message = "Invalid image name."
                });
            }

            try
            {
                var result = await _blobStorage.DownloadAsync(blobName);

                return File(result.Content, result.ContentType);
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return NotFound(new
                {
                    message = "Image not found."
                });
            }
            catch (RequestFailedException)
            {
                return StatusCode(502, new
                {
                    message = "Unable to retrieve image from Azure."
                });
            }
        }
    }
}
