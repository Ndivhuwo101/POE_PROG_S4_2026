﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public ResultsController(RaceDayContext context)
        {
            _context = context;
        }

        // GET: api/Results
        [HttpGet]
        public async Task<IActionResult> GetResults()
        {
            var results = await _context.Results
                .AsNoTracking()
                .ToListAsync();

            return Ok(results);
        }

        // GET: api/Results/1
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetResult(int id)
        {
            var result = await _context.Results
                .AsNoTracking()
                .FirstOrDefaultAsync(r => r.Result_ID == id);

            if (result == null)
                return NotFound(new
                {
                    message = "Result not found."
                });

            return Ok(result);
        }

        // POST: api/Results
        [HttpPost]
        public async Task<IActionResult> CreateResult(
            [FromBody] Result result)
        {
            var enrolmentExists = await _context.Enrolments
                .AnyAsync(e => e.Enrolment_ID == result.Enrolment_ID);

            if (!enrolmentExists)
                return BadRequest(new
                {
                    message = "Enrolment not found."
                });

            var organiserExists = await _context.Organisers
                .AnyAsync(o => o.Organiser_ID == result.Organiser_ID);

            if (!organiserExists)
                return BadRequest(new
                {
                    message = "Organiser not found."
                });

            result.Result_ID = 0;

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetResult),
                new { id = result.Result_ID },
                result);
        }

        // PUT: api/Results/1
        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateResult(
            int id,
            [FromBody] Result result)
        {
            if (id != result.Result_ID)
                return BadRequest(new
                {
                    message = "The URL ID and body ID must match."
                });

            var existing = await _context.Results.FindAsync(id);

            if (existing == null)
                return NotFound(new
                {
                    message = "Result not found."
                });

            var enrolmentExists = await _context.Enrolments
                .AnyAsync(e => e.Enrolment_ID == result.Enrolment_ID);

            if (!enrolmentExists)
                return BadRequest(new
                {
                    message = "Enrolment not found."
                });

            var organiserExists = await _context.Organisers
                .AnyAsync(o => o.Organiser_ID == result.Organiser_ID);

            if (!organiserExists)
                return BadRequest(new
                {
                    message = "Organiser not found."
                });

            existing.Enrolment_ID = result.Enrolment_ID;
            existing.Organiser_ID = result.Organiser_ID;
            existing.finish_time = result.finish_time;
            existing.position = result.position;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Results/1
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteResult(int id)
        {
            var result = await _context.Results.FindAsync(id);

            if (result == null)
                return NotFound(new
                {
                    message = "Result not found."
                });

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
