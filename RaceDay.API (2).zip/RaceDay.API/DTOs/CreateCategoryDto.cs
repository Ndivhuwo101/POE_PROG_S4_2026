﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.DTOs
{
    public class CreateCategoryDto
    {
        [Required]
        [StringLength(100, MinimumLength = 1)]
        public string name { get; set; } = string.Empty;

        [Range(typeof(decimal), "0.01", "1000")]
        public decimal distance_km { get; set; }

        [Range(1, int.MaxValue)]
        public int max_participants { get; set; }
    }
}
