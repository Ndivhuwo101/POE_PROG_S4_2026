﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.DTOs
{
    public class RegisterParticipantDto
    {
        [Required, StringLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required, StringLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required, EmailAddress, StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required, MinLength(8), StringLength(100)]
        public string Password { get; set; } = string.Empty;

        public DateTime DateOfBirth { get; set; }

        [StringLength(20)]
        public string? Gender { get; set; }
    }
}