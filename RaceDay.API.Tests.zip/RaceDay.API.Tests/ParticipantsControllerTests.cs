﻿
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;
using RaceDay.API.Models;


using RaceDay.API.Controllers;
using RaceDay.API.Data;

namespace RaceDay.API.Tests
{
    public class ParticipantsControllerTests
    {
        [Fact]
        public async Task GetParticipant_ReturnsNotFound_WhenParticipantDoesNotExist()
        {
            // Arrange: create a separate in-memory database
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);
            var controller = new ParticipantsController(context);

            // Act: request a participant ID that does not exist
            var result = await controller.GetParticipant(999999);

            // Assert: expect HTTP 404 Not Found
            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task GetParticipant_ReturnsOk_WhenParticipantExists()
        {
            // Arrange: create an isolated in-memory database
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            // Insert a test participant
            var participant = new Participant
            {
                Participant_ID = 1,
                first_name = "Test",
                last_name = "Runner",
                email = "test.runner@example.com",
                password_hash = "TestHash",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other",
                created_at = DateTime.UtcNow
            };

            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            var controller = new ParticipantsController(context);

            // Act
            var result = await controller.GetParticipant(1);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);
        }

        [Fact]
        public async Task GetParticipants_ReturnsAllParticipants()
        {
            // Arrange: create an isolated in-memory database
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            // Insert two test participants
            context.Participants.AddRange(
                new Participant
                {
                    Participant_ID = 1,
                    first_name = "John",
                    last_name = "Runner",
                    email = "john.runner@example.com",
                    password_hash = "TestHash1",
                    date_of_birth = new DateTime(2000, 1, 1),
                    gender = "Male",
                    created_at = DateTime.UtcNow
                },
                new Participant
                {
                    Participant_ID = 2,
                    first_name = "Jane",
                    last_name = "Athlete",
                    email = "jane.athlete@example.com",
                    password_hash = "TestHash2",
                    date_of_birth = new DateTime(2001, 5, 10),
                    gender = "Female",
                    created_at = DateTime.UtcNow
                }
            );

            await context.SaveChangesAsync();

            var controller = new ParticipantsController(context);

            // Act
            var result = await controller.GetParticipants();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

            var participants = Assert.IsAssignableFrom<
                System.Collections.IEnumerable>(okResult.Value);

            var count = 0;
            foreach (var participant in participants)
            {
                Assert.NotNull(participant);
                count++;
            }

            Assert.Equal(2, count);
        }

        [Fact]
        public async Task CreateParticipant_ReturnsCreated_WhenParticipantIsValid()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var controller = new ParticipantsController(context);

            var participant = new Participant
            {
                first_name = "Alex",
                last_name = "Morgan",
                email = "alex.morgan@example.com",
                password_hash = "TestHash123",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other"
            };

            // Act
            var result = await controller.CreateParticipant(participant);

            // Assert
            var createdResult = Assert.IsType<CreatedAtActionResult>(result);

            Assert.Equal(nameof(ParticipantsController.GetParticipant),
                         createdResult.ActionName);

            Assert.Equal(1, await context.Participants.CountAsync());

            var savedParticipant = await context.Participants
                .SingleAsync(p => p.email == "alex.morgan@example.com");

            Assert.Equal("Alex", savedParticipant.first_name);
            Assert.Equal("Morgan", savedParticipant.last_name);
            Assert.NotNull(savedParticipant.created_at);
        }

        [Fact]
        public async Task CreateParticipant_ReturnsConflict_WhenEmailAlreadyExists()
        {
            // Arrange: create an isolated in-memory database
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            // Insert the original participant
            context.Participants.Add(new Participant
            {
                Participant_ID = 1,
                first_name = "Alex",
                last_name = "Morgan",
                email = "alex.morgan@example.com",
                password_hash = "TestHash123",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other"
            });

            await context.SaveChangesAsync();

            var controller = new ParticipantsController(context);

            // Attempt to create another participant with the same email
            var duplicateParticipant = new Participant
            {
                first_name = "Jordan",
                last_name = "Smith",
                email = "alex.morgan@example.com",
                password_hash = "AnotherTestHash",
                date_of_birth = new DateTime(2001, 2, 2),
                gender = "Other"
            };

            // Act
            var result = await controller.CreateParticipant(duplicateParticipant);

            // Assert
            Assert.IsType<ConflictObjectResult>(result);

            // Verify that no duplicate was inserted
            Assert.Equal(1, await context.Participants.CountAsync());
        }

        [Fact]
        public async Task UpdateParticipant_ReturnsNoContent_WhenUpdateIsSuccessful()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var existingParticipant = new Participant
            {
                Participant_ID = 1,
                first_name = "Alex",
                last_name = "Morgan",
                email = "alex@example.com",
                password_hash = "OriginalHash",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other",
                created_at = DateTime.UtcNow
            };

            context.Participants.Add(existingParticipant);
            await context.SaveChangesAsync();

            var controller = new ParticipantsController(context);

            var updatedParticipant = new Participant
            {
                Participant_ID = 1,
                first_name = "Alexandra",
                last_name = "Morgan",
                email = "alexandra@example.com",
                password_hash = "ShouldNotBeApplied",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other"
            };

            // Act
            var result = await controller.UpdateParticipant(1, updatedParticipant);

            // Assert
            Assert.IsType<NoContentResult>(result);

            var savedParticipant = await context.Participants
                .SingleAsync(p => p.Participant_ID == 1);

            Assert.Equal("Alexandra", savedParticipant.first_name);
            Assert.Equal("alexandra@example.com", savedParticipant.email);

            // Password and creation timestamp should remain unchanged
            Assert.Equal("OriginalHash", savedParticipant.password_hash);
            Assert.Equal(existingParticipant.created_at, savedParticipant.created_at);
        }

        [Fact]
        public async Task UpdateParticipant_ReturnsNotFound_WhenParticipantDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var controller = new ParticipantsController(context);

            var participant = new Participant
            {
                Participant_ID = 999,
                first_name = "Test",
                last_name = "Runner",
                email = "missing@example.com",
                password_hash = "TestHash",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other"
            };

            // Act
            var result = await controller.UpdateParticipant(999, participant);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result);

            // Confirm that no participant was inserted
            Assert.Equal(0, await context.Participants.CountAsync());
        }

        [Fact]
        public async Task DeleteParticipant_ReturnsNoContent_WhenParticipantExists()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var participant = new Participant
            {
                Participant_ID = 1,
                first_name = "Alex",
                last_name = "Morgan",
                email = "alex.delete@example.com",
                password_hash = "TestHash",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other"
            };

            context.Participants.Add(participant);
            await context.SaveChangesAsync();

            var controller = new ParticipantsController(context);

            // Act
            var result = await controller.DeleteParticipant(1);

            // Assert
            Assert.IsType<NoContentResult>(result);

            // Verify that the participant was deleted
            Assert.Equal(0, await context.Participants.CountAsync());
        }

        [Fact]
        public async Task DeleteParticipant_ReturnsNotFound_WhenParticipantDoesNotExist()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var controller = new ParticipantsController(context);

            // Act
            var result = await controller.DeleteParticipant(999999);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result);

            // Verify that the database remains empty
            Assert.Equal(0, await context.Participants.CountAsync());
        }

[Fact]
public async Task UpdateParticipant_ReturnsBadRequest_WhenIdsDoNotMatch()
{
    // Arrange
    var options = new DbContextOptionsBuilder<RaceDayContext>()
        .UseInMemoryDatabase(Guid.NewGuid().ToString())
        .Options;

    using var context = new RaceDayContext(options);

    context.Participants.Add(new Participant
    {
        Participant_ID = 1,
        first_name = "Alex",
        last_name = "Morgan",
        email = "alex@example.com",
        password_hash = "TestHash",
        date_of_birth = new DateTime(2000, 1, 1),
        gender = "Other"
    });

    await context.SaveChangesAsync();

    var controller = new ParticipantsController(context);

    var updatedParticipant = new Participant
    {
        Participant_ID = 2,
        first_name = "Alex",
        last_name = "Updated",
        email = "alex.updated@example.com",
        password_hash = "TestHash",
        date_of_birth = new DateTime(2000, 1, 1),
        gender = "Other"
    };

    // Act: URL ID is 1, body ID is 2
    var result = await controller.UpdateParticipant(1, updatedParticipant);

    // Assert
    Assert.IsType<BadRequestObjectResult>(result);

    // Confirm the original record was not changed
    var savedParticipant = await context.Participants
        .SingleAsync(p => p.Participant_ID == 1);

    Assert.Equal("Morgan", savedParticipant.last_name);
    Assert.Equal("alex@example.com", savedParticipant.email);
}


        [Fact]
        public async Task DeleteParticipant_ReturnsConflict_WhenParticipantHasEnrolments()
        {
            // Arrange: create an isolated in-memory database
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            // Create a participant
            var participant = new Participant
            {
                Participant_ID = 1,
                first_name = "Alex",
                last_name = "Morgan",
                email = "alex.enrolled@example.com",
                password_hash = "TestHash",
                date_of_birth = new DateTime(2000, 1, 1),
                gender = "Other"
            };

            context.Participants.Add(participant);

            // Create an enrolment linked to that participant
            var enrolment = new Enrolment
            {
                Enrolment_ID = 1,
                Participant_ID = 1,
                Category_ID = 1,
                enrolled_at = DateTime.UtcNow,
                status = "Confirmed"
            };

            context.Enrolments.Add(enrolment);
            await context.SaveChangesAsync();

            var controller = new ParticipantsController(context);

            // Act
            var result = await controller.DeleteParticipant(1);

            // Assert: deletion must be blocked
            Assert.IsType<ConflictObjectResult>(result);

            // Confirm the participant still exists
            Assert.Equal(
                1,
                await context.Participants.CountAsync(
                    p => p.Participant_ID == 1));
        }




    }
}
