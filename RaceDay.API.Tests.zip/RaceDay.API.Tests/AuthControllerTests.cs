using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Xunit;

using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

namespace RaceDay.API.Tests
{
    public class AuthControllerTests
    {
        private readonly string _jwtKey =
            "RaceDayUnitTestingSecretKey2026_123456789";

        private RaceDayContext GetDatabaseContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new RaceDayContext(options);
        }

        private IConfiguration GetConfiguration()
        {
            var settings = new Dictionary<string, string?>
            {
                ["Jwt:Key"] = _jwtKey,
                ["Jwt:Issuer"] = "RaceDay.API",
                ["Jwt:Audience"] = "RaceDay.Client"
            };

            return new ConfigurationBuilder()
                .AddInMemoryCollection(settings)
                .Build();
        }

        [Fact]
        public async Task RegisterParticipant_CreatesParticipant()
        {
            // Arrange
            using var context = GetDatabaseContext();

            var controller = new AuthController(
                context, GetConfiguration());

            var request = new RegisterParticipantDto
            {
                FirstName = "Test",
                LastName = "Runner",
                Email = "test.runner@example.com",
                Password = "TestPassword123!",
                DateOfBirth = new DateTime(2000, 1, 1),
                Gender = "Other"
            };

            // Act
            var result = await controller.RegisterParticipant(request);

            // Assert
            Assert.NotNull(result);

            var participant = await context.Participants
                .SingleOrDefaultAsync(
                    p => p.email == "test.runner@example.com");

            Assert.NotNull(participant);
            Assert.Equal("Test", participant.first_name);
            Assert.Equal("Runner", participant.last_name);
        }

        [Fact]
        public async Task RegisterParticipant_RejectsDuplicateEmail()
        {
            // Arrange
            using var context = GetDatabaseContext();

            var controller = new AuthController(
                context, GetConfiguration());

            var request = new RegisterParticipantDto
            {
                FirstName = "Test",
                LastName = "Runner",
                Email = "duplicate@example.com",
                Password = "TestPassword123!",
                DateOfBirth = new DateTime(2000, 1, 1),
                Gender = "Other"
            };

            // Act
            await controller.RegisterParticipant(request);
            var secondResult =
                await controller.RegisterParticipant(request);

            // Assert
            Assert.NotNull(secondResult);
        }

        [Fact]
        public async Task Login_WithInvalidCredentials_ReturnsUnauthorized()
        {
            // Arrange
            using var context = GetDatabaseContext();

            var controller = new AuthController(
                context, GetConfiguration());

            var request = new LoginDto
            {
                Email = "missing@example.com",
                Password = "WrongPassword123!"
            };

            // Act
            var result = await controller.Login(request);

            // Assert
            Assert.IsType<UnauthorizedObjectResult>(result);
        }
    }
}