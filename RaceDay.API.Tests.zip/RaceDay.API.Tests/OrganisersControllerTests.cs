﻿
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using raceDay.Models;

namespace RaceDay.API.Tests
{
    public class OrganisersControllerTests
    {
        [Fact]
        public async Task GetOrganisers_ReturnsOk_WithOrganisers()
        {
            // Arrange
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            context.Organisers.AddRange(
                new Organiser
                {
                    Organiser_ID = 1,
                    FirstName = "Alex",
                    LastName = "Morgan",
                    Email = "alex@example.com",
                    PasswordHash = "TestHash1",
                    CreatedAt = DateTime.UtcNow
                },
                new Organiser
                {
                    Organiser_ID = 2,
                    FirstName = "Jordan",
                    LastName = "Smith",
                    Email = "jordan@example.com",
                    PasswordHash = "TestHash2",
                    CreatedAt = DateTime.UtcNow
                }
            );

            await context.SaveChangesAsync();

            var controller = new OrganisersController(context);

            // Act
            var result = await controller.GetOrganisers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

            var organisers = Assert.IsAssignableFrom<
                System.Collections.IEnumerable>(okResult.Value);

            var count = 0;
            foreach (var organiser in organisers)
            {
                Assert.NotNull(organiser);
                count++;
            }

            Assert.Equal(2, count);
        }

        [Fact]
        public async Task GetOrganiser_ReturnsOk_WhenOrganiserExists()
        {
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            context.Organisers.Add(new Organiser
            {
                Organiser_ID = 1,
                FirstName = "Alex",
                LastName = "Morgan",
                Email = "alex@example.com",
                PasswordHash = "TestHash",
                CreatedAt = DateTime.UtcNow
            });

            await context.SaveChangesAsync();

            var controller = new OrganisersController(context);

            var result = await controller.GetOrganiser(1);

            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);
        }

        [Fact]
        public async Task GetOrganiser_ReturnsNotFound_WhenOrganiserDoesNotExist()
        {
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var controller = new OrganisersController(context);

            var result = await controller.GetOrganiser(999999);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        [Fact]
        public async Task CreateOrganiser_ReturnsCreated_WhenOrganiserIsValid()
        {
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var controller = new OrganisersController(context);

            var organiser = new Organiser
            {
                FirstName = "Jordan",
                LastName = "Smith",
                Email = "jordan@example.com",
                PasswordHash = "TestHash"
            };

            var result = await controller.CreateOrganiser(organiser);

            var createdResult = Assert.IsType<CreatedAtActionResult>(result);

            Assert.Equal(
                nameof(OrganisersController.GetOrganiser),
                createdResult.ActionName);

            Assert.Equal(1, await context.Organisers.CountAsync());

            var savedOrganiser = await context.Organisers
                .SingleAsync(o => o.Email == "jordan@example.com");

            Assert.Equal("Jordan", savedOrganiser.FirstName);
            Assert.NotNull(savedOrganiser.CreatedAt);
        }

        [Fact]
        public async Task UpdateOrganiser_ReturnsNoContent_WhenUpdateIsSuccessful()
        {
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            using var context = new RaceDayContext(options);

            var originalCreatedAt = DateTime.UtcNow.AddDays(-5);

            context.Organisers.Add(new Organiser
            {
                Organiser_ID = 1,
                FirstName = "Alex",
                LastName = "Morgan",
                Email = "alex@example.com",
                PasswordHash = "OriginalHash",
                CreatedAt = originalCreatedAt
            });

            await context.SaveChangesAsync();

            var controller = new OrganisersController(context);

            var updatedOrganiser = new Organiser
            {
                Organiser_ID = 1,
                FirstName = "Alexandra",
                LastName = "Morgan",
                Email = "alexandra@example.com",
                PasswordHash = "NewHash"
            };

            var result = await controller.UpdateOrganiser(1, updatedOrganiser);

            Assert.IsType<NoContentResult>(result);

            var savedOrganiser = await context.Organisers
                .SingleAsync(o => o.Organiser_ID == 1);

            Assert.Equal("Alexandra", savedOrganiser.FirstName);
            Assert.Equal("alexandra@example.com", savedOrganiser.Email);
            Assert.Equal("OriginalHash", savedOrganiser.PasswordHash);
            Assert.Equal(originalCreatedAt, savedOrganiser.CreatedAt);
        }




    }
}
