﻿
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.Models;
using raceDay.Models;

namespace RaceDay.API.Tests
{
    public class ResultsControllerTests
    {
        private static RaceDayContext CreateContext()
        {
            var options = new DbContextOptionsBuilder<RaceDayContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new RaceDayContext(options);
        }

        private static async Task SeedDependencies(RaceDayContext context)
        {
            context.Organisers.Add(new Organiser
            {
                Organiser_ID = 1,
                FirstName = "Alex",
                LastName = "Morgan",
                Email = "alex@example.com",
                PasswordHash = "TestHash",
                CreatedAt = DateTime.UtcNow
            });

            context.Enrolments.Add(new Enrolment
            {
                Enrolment_ID = 1
            });

            await context.SaveChangesAsync();
        }

        private static Result CreateSampleResult(int id = 1)
        {
            return new Result
            {
                Result_ID = id,
                Enrolment_ID = 1,
                Organiser_ID = 1,
                finish_time = new TimeSpan(0, 45, 30),
                position = 1,
                captured_at = DateTime.UtcNow
            };
        }

        [Fact]
        public async Task GetResults_ReturnsOk_WithResults()
        {
            using var context = CreateContext();

            context.Results.AddRange(
                CreateSampleResult(1),
                new Result
                {
                    Result_ID = 2,
                    Enrolment_ID = 2,
                    Organiser_ID = 2,
                    finish_time = new TimeSpan(0, 50, 15),
                    position = 2,
                    captured_at = DateTime.UtcNow
                });

            await context.SaveChangesAsync();

            var controller = new ResultsController(context);

            var response = await controller.GetResults();

            var ok = Assert.IsType<OkObjectResult>(response);
            var results = Assert.IsAssignableFrom<
                System.Collections.Generic.IEnumerable<Result>>(ok.Value);

            Assert.Equal(2, results.Count());
        }

        [Fact]
        public async Task GetResult_ReturnsOk_WhenResultExists()
        {
            using var context = CreateContext();
            context.Results.Add(CreateSampleResult());
            await context.SaveChangesAsync();

            var controller = new ResultsController(context);

            var response = await controller.GetResult(1);

            var ok = Assert.IsType<OkObjectResult>(response);
            var result = Assert.IsType<Result>(ok.Value);

            Assert.Equal(1, result.Result_ID);
            Assert.Equal(1, result.position);
        }

        [Fact]
        public async Task GetResult_ReturnsNotFound_WhenResultDoesNotExist()
        {
            using var context = CreateContext();
            var controller = new ResultsController(context);

            var response = await controller.GetResult(999);

            Assert.IsType<NotFoundObjectResult>(response);
        }

        [Fact]
        public async Task CreateResult_ReturnsCreated_WhenDependenciesExist()
        {
            using var context = CreateContext();
            await SeedDependencies(context);

            var controller = new ResultsController(context);
            var result = CreateSampleResult();

            var response = await controller.CreateResult(result);

            var created = Assert.IsType<CreatedAtActionResult>(response);
            Assert.Equal(nameof(ResultsController.GetResult), created.ActionName);
            Assert.Equal(1, await context.Results.CountAsync());
            Assert.True(result.Result_ID > 0);
        }

        [Fact]
        public async Task CreateResult_ReturnsBadRequest_WhenEnrolmentDoesNotExist()
        {
            using var context = CreateContext();

            context.Organisers.Add(new Organiser
            {
                Organiser_ID = 1,
                FirstName = "Alex",
                LastName = "Morgan",
                Email = "alex@example.com",
                PasswordHash = "TestHash",
                CreatedAt = DateTime.UtcNow
            });

            await context.SaveChangesAsync();

            var controller = new ResultsController(context);
            var result = CreateSampleResult();
            result.Enrolment_ID = 999;

            var response = await controller.CreateResult(result);

            Assert.IsType<BadRequestObjectResult>(response);
            Assert.Equal(0, await context.Results.CountAsync());
        }

        [Fact]
        public async Task CreateResult_ReturnsBadRequest_WhenOrganiserDoesNotExist()
        {
            using var context = CreateContext();

            context.Enrolments.Add(new Enrolment
            {
                Enrolment_ID = 1
            });

            await context.SaveChangesAsync();

            var controller = new ResultsController(context);
            var result = CreateSampleResult();
            result.Organiser_ID = 999;

            var response = await controller.CreateResult(result);

            Assert.IsType<BadRequestObjectResult>(response);
            Assert.Equal(0, await context.Results.CountAsync());
        }

        [Fact]
        public async Task UpdateResult_ReturnsNoContent_WhenUpdateSucceeds()
        {
            using var context = CreateContext();
            await SeedDependencies(context);

            context.Results.Add(CreateSampleResult());
            await context.SaveChangesAsync();

            var controller = new ResultsController(context);

            var updated = new Result
            {
                Result_ID = 1,
                Enrolment_ID = 1,
                Organiser_ID = 1,
                finish_time = new TimeSpan(0, 40, 10),
                position = 2,
                captured_at = DateTime.UtcNow
            };

            var response = await controller.UpdateResult(1, updated);

            Assert.IsType<NoContentResult>(response);

            var saved = await context.Results.FindAsync(1);
            Assert.NotNull(saved);
            Assert.Equal(new TimeSpan(0, 40, 10), saved.finish_time);
            Assert.Equal(2, saved.position);
        }

        [Fact]
        public async Task UpdateResult_ReturnsBadRequest_WhenIdsDoNotMatch()
        {
            using var context = CreateContext();
            var controller = new ResultsController(context);
            var result = CreateSampleResult(2);

            var response = await controller.UpdateResult(1, result);

            Assert.IsType<BadRequestObjectResult>(response);
        }

        [Fact]
        public async Task UpdateResult_ReturnsNotFound_WhenResultDoesNotExist()
        {
            using var context = CreateContext();
            var controller = new ResultsController(context);

            var response = await controller.UpdateResult(
                999, CreateSampleResult(999));

            Assert.IsType<NotFoundObjectResult>(response);
        }

        [Fact]
        public async Task DeleteResult_ReturnsNoContent_WhenResultExists()
        {
            using var context = CreateContext();
            context.Results.Add(CreateSampleResult());
            await context.SaveChangesAsync();

            var controller = new ResultsController(context);

            var response = await controller.DeleteResult(1);

            Assert.IsType<NoContentResult>(response);
            Assert.Equal(0, await context.Results.CountAsync());
        }

        [Fact]
        public async Task DeleteResult_ReturnsNotFound_WhenResultDoesNotExist()
        {
            using var context = CreateContext();
            var controller = new ResultsController(context);

            var response = await controller.DeleteResult(999);

            Assert.IsType<NotFoundObjectResult>(response);
        }
    }
}
